while true; do
    read -p "Running this SH will make modifcations to multiple root files and installs. Proceed? [Y/N]" yn
    case $yn in
        [Yy]* ) echo "Thank you for confirming."; break;;
        [Nn]* ) exit;;
        * ) echo "Please answer yes or no.";;
    esac

sudo apt-get install cheese
sudo apt-get install wine64
sudo apt-get install gparted
sudo apt-get install stress
sudo apt-get install arecord
sudo apt-get install speaker-test
sudo apt-get install speed-test
sudo apt-get install acpi

echo "complete."
