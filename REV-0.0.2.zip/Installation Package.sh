sudo apt-get install cheese
sudo apt-get install wine64
sudo apt-get install gparted
sudo apt-get install stress
sudo apt-get install arecord
sudo apt-get install speaker-test
sudo apt-get install speed-test
sudo apt-get install acpi

echo "complete."
