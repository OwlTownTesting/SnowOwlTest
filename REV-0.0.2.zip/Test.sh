echo "This SH is designed to automate the standard testing procedure for EBAY LAPTOPs for brooksville, FL Tech Center"
echo "Rights of use have been given to regency, however this package will not be updated freely nor is modifcation allowed"
echo "WARNING: BEING UNMANAGED, THIS TEST COULD BRICK THE DRIVE IT IS INSTALLED ON IF USED INCORRECTLY, FOLLOW DOC"
echo ""

    while true; do
        read -p "Approximated Testing time is 5-10 minutes. Do you wish to continue? [Y/N]" yn
        case $yn in
            [Yy]* ) echo "Thank you for confirming."; break;;
            [Nn]* ) exit;;
            * ) echo "Please answer yes or no.";;
        esac
    done

echo "Starting Testing Script"
echo ""

    echo "Root Launch: Cheese"
        sudo cheese
        #cheese is used as the main camera GUI; Found to have the most intact driver configuration for laptop devices;
    echo "Cheese closed, next testing starting"
    echo ""

echo ""

    echo "WINE LAUNCHER: AquaKeyTest"
        sudo wine /home/Mint/Desktop/AquaKeyTest.exe
        #use what keyboard test best suits your need, AquaKeyTest of PassMark Keyboard test are both solid options, but your results may differ. 
    echo "Aqua closed, hard drive information processing"

echo ""
echo ""

    echo "verify disk is present. WARNING: DO NOT SELECT THE PORTABLE DISK DRIVE YOU ARE CURRENTLY OPERATING ON"
    echo "TWO OR MORE DISKS SHOULD BE PRESENT"
        sudo gparted
        ##clearing disks 
    echo "Disk wipe completed"

echo ""
sleep 5

echo ""
    echo "Starting stress test"
    echo "Stress-ng is designed to stress via CLI"
    echo "THIS TEST MAY TAKE UP TO 5 MINUTES TO COMPLETE. DO NOT CLOSE THIS WINDOW" 
        sudo stress --cpu 8 --io 4 --vm 2 --vm-bytes 128M --hdd 1 --timeout 180s 
    echo "stress test complete"

echo ""
sleep 10

    echo "Sound testing starting"
        sudo arecord -vvv -f dat /dev/null -d 3
        speaker-test -l 1 -t sine
        speaker-test -l 1 -t pink
    echo "Sound Tests Complete."

sleep 5

echo ""
        echo "starting network test"
        sudo speedtest
        echo ""
        echo "speed test complete."
sleep 10

echo "System testing complete."
echo "Gathering system information for Portal"
echo ""
echo ""
echo ""

echo "Battery Information"
sudo acpi -i
echo ""

sudo dmidecode | grep -A3 '^System Information' 
sudo dmidecode -s system-serial-number
echo ""
echo "CPU information"
sudo dmidecode -t processor | grep "Version"
sudo dmidecode -t processor | grep "Max Speed"
sudo dmidecode -t processor | grep "Core Count" 
sudo dmidecode -t processor | grep "Thread Count"

echo ""
echo "RAM information"
sudo dmidecode --type 17 | grep "Size" 
echo ""
echo "GFX Information"
sudo lshw -c video -short && xdpyinfo | grep 'dimensions:'
echo ""
echo "Disk Information"
sudo lshw -c disk -short

echo ""
echo ""
echo ""
echo "Task completed"
